from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from werkzeug.security import generate_password_hash, check_password_hash
from config import Config
from utils.database import execute_query
from utils.validators import is_valid_email, is_strong_password, validate_property_data
import os

app = Flask(__name__)
app.config.from_object(Config)

# Custom filter for currency formatting
@app.template_filter('currency')
def currency_filter(value):
    try:
        return f"${float(value):,.2f}"
    except (ValueError, TypeError):
        return value

# Context processor to inject user into all templates
@app.context_processor
def inject_user():
    user = None
    if 'user_id' in session:
        user = execute_query("SELECT id, name, role FROM users WHERE id = %s", (session['user_id'],), fetch=True, fetchall=False)
    return dict(current_user=user)

# --- Routes ---

@app.route('/')
def index():
    # Fetch 3 recent properties for the home page
    featured_properties = execute_query(
        "SELECT * FROM properties ORDER BY created_at DESC LIMIT 3", fetch=True
    )
    return render_template('index.html', properties=featured_properties)

@app.route('/listings')
def listings():
    # Base query
    query = "SELECT * FROM properties WHERE 1=1"
    params = []
    
    # Handle Search & Filters
    keyword = request.args.get('keyword', '')
    location = request.args.get('location', '')
    prop_type = request.args.get('type', '')
    status = request.args.get('status', '')
    min_price = request.args.get('min_price', '')
    max_price = request.args.get('max_price', '')
    sort = request.args.get('sort', 'newest')

    if keyword:
        query += " AND (title LIKE %s OR description LIKE %s)"
        params.extend([f"%{keyword}%", f"%{keyword}%"])
    
    if location:
        query += " AND location LIKE %s"
        params.append(f"%{location}%")
        
    if prop_type:
        query += " AND property_type = %s"
        params.append(prop_type)
        
    if status:
        query += " AND status = %s"
        params.append(status)
        
    if min_price:
        try:
            query += " AND price >= %s"
            params.append(float(min_price))
        except ValueError:
            pass
            
    if max_price:
        try:
            query += " AND price <= %s"
            params.append(float(max_price))
        except ValueError:
            pass
            
    # Handle Sorting
    if sort == 'price_asc':
        query += " ORDER BY price ASC"
    elif sort == 'price_desc':
        query += " ORDER BY price DESC"
    else:
        query += " ORDER BY created_at DESC"
        
    properties = execute_query(query, tuple(params), fetch=True)
    return render_template('listings.html', properties=properties)

@app.route('/property/<int:id>')
def property_details(id):
    property = execute_query("SELECT * FROM properties WHERE id = %s", (id,), fetch=True, fetchall=False)
    if not property:
        abort(404)
        
    agent = execute_query("SELECT name, email, phone FROM users WHERE id = %s", (property['agent_id'],), fetch=True, fetchall=False)
    
    # Check if favorited
    is_favorite = False
    if 'user_id' in session:
        fav = execute_query("SELECT id FROM favorites WHERE user_id = %s AND property_id = %s", 
                           (session['user_id'], id), fetch=True, fetchall=False)
        is_favorite = bool(fav)
        
    return render_template('property_details.html', property=property, agent=agent, is_favorite=is_favorite)

@app.route('/property/<int:id>/inquire', methods=['POST'])
def inquire(id):
    name = request.form.get('name')
    email = request.form.get('email')
    phone = request.form.get('phone')
    message = request.form.get('message')
    
    if not name or not email or not message:
        flash('Please fill out all required fields.', 'error')
    elif not is_valid_email(email):
        flash('Invalid email address.', 'error')
    else:
        execute_query(
            "INSERT INTO inquiries (property_id, name, email, phone, message) VALUES (%s, %s, %s, %s, %s)",
            (id, name, email, phone, message)
        )
        flash('Your inquiry has been sent successfully! The agent will contact you soon.', 'success')
        
    return redirect(url_for('property_details', id=id))

# --- Authentication Routes ---

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('index'))
        
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        role = request.form.get('role', 'user') # Allow selecting 'agent' role for demo
        
        if not is_valid_email(email):
            flash('Invalid email address.', 'error')
        elif not is_strong_password(password):
            flash('Password must be at least 8 characters long.', 'error')
        else:
            # Check if email exists
            existing_user = execute_query("SELECT id FROM users WHERE email = %s", (email,), fetch=True, fetchall=False)
            if existing_user:
                flash('Email already registered.', 'error')
            else:
                hashed_password = generate_password_hash(password)
                execute_query(
                    "INSERT INTO users (name, email, password_hash, role) VALUES (%s, %s, %s, %s)",
                    (name, email, hashed_password, role)
                )
                flash('Registration successful! Please log in.', 'success')
                return redirect(url_for('login'))
                
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('index'))
        
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = execute_query("SELECT id, password_hash, role, name FROM users WHERE email = %s", (email,), fetch=True, fetchall=False)
        
        if user and check_password_hash(user['password_hash'], password):
            session['user_id'] = user['id']
            session['role'] = user['role']
            session['name'] = user['name']
            flash('Logged in successfully!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid email or password.', 'error')
            
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

# --- Management Routes (Protected) ---

@app.route('/manage')
def manage_listings():
    if 'user_id' not in session or session.get('role') not in ['agent', 'admin']:
        flash('You do not have permission to view this page.', 'error')
        return redirect(url_for('index'))
        
    properties = execute_query("SELECT * FROM properties WHERE agent_id = %s ORDER BY created_at DESC", 
                              (session['user_id'],), fetch=True)
    return render_template('manage_listings.html', properties=properties)

@app.route('/property/add', methods=['GET', 'POST'])
def add_property():
    if 'user_id' not in session or session.get('role') not in ['agent', 'admin']:
        flash('You do not have permission to add properties.', 'error')
        return redirect(url_for('index'))
        
    if request.method == 'POST':
        errors = validate_property_data(request.form)
        
        if errors:
            for error in errors:
                flash(error, 'error')
        else:
            execute_query(
                """INSERT INTO properties 
                   (agent_id, title, description, price, location, property_type, status, bedrooms, bathrooms, area, image_url, amenities) 
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                (
                    session['user_id'],
                    request.form.get('title'),
                    request.form.get('description'),
                    request.form.get('price'),
                    request.form.get('location'),
                    request.form.get('property_type'),
                    request.form.get('status'),
                    request.form.get('bedrooms', 0) or 0,
                    request.form.get('bathrooms', 0) or 0,
                    request.form.get('area'),
                    request.form.get('image_url'),
                    request.form.get('amenities')
                )
            )
            flash('Property added successfully!', 'success')
            return redirect(url_for('manage_listings'))
            
    return render_template('add_property.html')

@app.route('/property/<int:id>/edit', methods=['GET', 'POST'])
def edit_property(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    property = execute_query("SELECT * FROM properties WHERE id = %s", (id,), fetch=True, fetchall=False)
    
    if not property:
        abort(404)
        
    # Only allow the agent who created it or an admin to edit
    if property['agent_id'] != session['user_id'] and session.get('role') != 'admin':
        flash('You do not have permission to edit this property.', 'error')
        return redirect(url_for('manage_listings'))
        
    if request.method == 'POST':
        errors = validate_property_data(request.form)
        if errors:
            for error in errors:
                flash(error, 'error')
        else:
            execute_query(
                """UPDATE properties SET 
                   title=%s, description=%s, price=%s, location=%s, property_type=%s, 
                   status=%s, bedrooms=%s, bathrooms=%s, area=%s, image_url=%s, amenities=%s
                   WHERE id=%s""",
                (
                    request.form.get('title'),
                    request.form.get('description'),
                    request.form.get('price'),
                    request.form.get('location'),
                    request.form.get('property_type'),
                    request.form.get('status'),
                    request.form.get('bedrooms', 0) or 0,
                    request.form.get('bathrooms', 0) or 0,
                    request.form.get('area'),
                    request.form.get('image_url'),
                    request.form.get('amenities'),
                    id
                )
            )
            flash('Property updated successfully!', 'success')
            return redirect(url_for('manage_listings'))
            
    return render_template('edit_property.html', property=property)

@app.route('/property/<int:id>/delete', methods=['POST'])
def delete_property(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    property = execute_query("SELECT agent_id FROM properties WHERE id = %s", (id,), fetch=True, fetchall=False)
    
    if property and (property['agent_id'] == session['user_id'] or session.get('role') == 'admin'):
        execute_query("DELETE FROM properties WHERE id = %s", (id,))
        flash('Property deleted successfully.', 'success')
    else:
        flash('You do not have permission to delete this property.', 'error')
        
    return redirect(url_for('manage_listings'))

@app.route('/favorites')
def favorites():
    if 'user_id' not in session:
        flash('Please log in to view favorites.', 'info')
        return redirect(url_for('login'))
        
    query = """
        SELECT p.* FROM properties p
        JOIN favorites f ON p.id = f.property_id
        WHERE f.user_id = %s
        ORDER BY f.created_at DESC
    """
    properties = execute_query(query, (session['user_id'],), fetch=True)
    return render_template('listings.html', properties=properties, title="My Favorites")

@app.route('/property/<int:id>/favorite', methods=['POST'])
def toggle_favorite(id):
    if 'user_id' not in session:
        flash('Please log in to save properties.', 'info')
        return redirect(url_for('login'))
        
    # Check if already favorited
    fav = execute_query("SELECT id FROM favorites WHERE user_id = %s AND property_id = %s", 
                       (session['user_id'], id), fetch=True, fetchall=False)
                       
    if fav:
        execute_query("DELETE FROM favorites WHERE id = %s", (fav['id'],))
        flash('Removed from favorites.', 'info')
    else:
        execute_query("INSERT INTO favorites (user_id, property_id) VALUES (%s, %s)", 
                     (session['user_id'], id))
        flash('Added to favorites!', 'success')
        
    return redirect(url_for('property_details', id=id))

# --- Static Pages ---

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        # In a real app, send an email here.
        # For this demo, just flash a success message.
        flash('Thank you for contacting us! We will get back to you shortly.', 'success')
        return redirect(url_for('contact'))
    return render_template('contact.html')

# --- Error Handlers ---

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return "500 Internal Server Error: The database might not be configured properly.", 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
