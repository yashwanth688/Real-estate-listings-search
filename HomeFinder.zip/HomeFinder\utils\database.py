import mysql.connector
from mysql.connector import Error
from config import Config

def get_db_connection():
    """Establish and return a connection to the MySQL database."""
    try:
        connection = mysql.connector.connect(
            host=Config.DB_HOST,
            user=Config.DB_USER,
            password=Config.DB_PASSWORD,
            database=Config.DB_NAME
        )
        if connection.is_connected():
            return connection
    except Error as e:
        print(f"Error while connecting to MySQL: {e}")
        return None

def execute_query(query, params=None, fetch=False, fetchall=True):
    """
    Execute a query safely using parameterized inputs.
    
    :param query: SQL query string with %s placeholders
    :param params: Tuple of parameters
    :param fetch: Boolean indicating whether to fetch results
    :param fetchall: Boolean indicating whether to fetch all rows or just one
    :return: Results (if fetch=True) or lastrowid (if insert) or None
    """
    connection = get_db_connection()
    if not connection:
        return None

    try:
        cursor = connection.cursor(dictionary=True) # Return rows as dictionaries
        cursor.execute(query, params or ())
        
        if fetch:
            if fetchall:
                result = cursor.fetchall()
            else:
                result = cursor.fetchone()
            return result
        
        # If it's an insert, update or delete
        connection.commit()
        return cursor.lastrowid
        
    except Error as e:
        print(f"Failed to execute query: {e}")
        return None
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
