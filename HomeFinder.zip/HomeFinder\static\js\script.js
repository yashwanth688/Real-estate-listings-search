document.addEventListener('DOMContentLoaded', function() {
    // Initialize Lucide icons
    lucide.createIcons();

    // Mobile Navigation Toggle
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const navLinks = document.getElementById('navLinks');

    if (mobileMenuBtn && navLinks) {
        mobileMenuBtn.addEventListener('click', function() {
            navLinks.classList.toggle('active');
        });
    }

    // Auto-hide flash messages after 5 seconds
    const flashMessages = document.querySelectorAll('.alert');
    if (flashMessages.length > 0) {
        setTimeout(() => {
            flashMessages.forEach(msg => {
                // Add fade out effect
                msg.style.transition = 'opacity 0.5s ease';
                msg.style.opacity = '0';
                
                // Remove from DOM after fade out
                setTimeout(() => {
                    msg.style.display = 'none';
                }, 500);
            });
        }, 5000);
    }

    // Basic frontend validation for property form
    const areaInput = document.querySelector('input[name="area"]');
    const priceInput = document.querySelector('input[name="price"]');
    
    if (areaInput && priceInput) {
        const form = areaInput.closest('form');
        if (form) {
            form.addEventListener('submit', function(e) {
                if (parseFloat(areaInput.value) <= 0) {
                    e.preventDefault();
                    alert('Area must be greater than zero.');
                }
                if (parseFloat(priceInput.value) <= 0) {
                    e.preventDefault();
                    alert('Price must be greater than zero.');
                }
            });
        }
    }
});
